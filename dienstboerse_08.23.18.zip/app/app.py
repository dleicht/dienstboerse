# -*- coding: utf-8 -*-
from flask import Flask
from flask import request
from flask import render_template
from flask import redirect, url_for, flash, g
from sqlalchemy import create_engine, MetaData, Table, desc, asc
from flask_recaptcha import ReCaptcha
#from flask_babel import Babel, gettext

app = Flask(__name__)
app.config.from_object('config')
#app.config.from_pyfile('mysettings.cfg')
#babel = Babel(app)

##########
# ReCaptcha config:
recaptcha = ReCaptcha(app=app)

##########
# pythonanywhere.com MySQL engine:
engine = create_engine('mysql+mysqldb://kickass:SQL-kickass-05@kickass.mysql.pythonanywhere-services.com/kickass$default', convert_unicode=True, pool_recycle=280)

##########
# local Sqlite engine
#engine = create_engine('sqlite:////Users/domi/Entwicklung/raidfinder.de/app/raidfinder.db', convert_unicode=True)

metadata = MetaData(bind=engine)
dienstboerse = Table('dienstboerse', metadata, autoload=True)

##########
# Babel config:
# @babel.localeselector
# def get_locale():
#     current_locale = request.accept_languages.best_match(app.config['LANGUAGES'].keys())
#     print current_locale
#     g.current_locale = current_locale
#     return current_locale

##########
# views galore:
@app.route('/de/index', methods=["GET", "POST"])
@app.route('/de', methods=["GET", "POST"])
@app.route('/index', methods=["GET", "POST"])
@app.route('/', methods=["GET", "POST"])
def de_form():
    if request.method == "GET":
        ergebnis = dienstboerse.select().where(dienstboerse.c.aktiv==1).order_by(asc('dienstdate')).execute().fetchall() # Super wichtig! Das .fetchall() macht das Objekt erst zum list-like-item, das dann iterable ist! ergebnis = [(1, u'2017-10-29 21:00', u'domi', u'Crotas Ende', 250, u"Domi's Party", u'domi.leicht@gmail.com'), (2, u'2017-10-29 21:00', u'Test', u'Test', 400, u'Test', None)]
        return render_template("de_form.html", ergebnis=ergebnis)

    if recaptcha.verify():
        # SUCCESS
        dienstdate = request.form['dienstdate']
        suchender = request.form['suchender']
        dienstart = request.form['dienstart']
        dienstgruppe = request.form['dienstgruppe']
        motivation = request.form['motivation']
        kommentar = request.form['kommentar']
        #annehmender = request.form['annehmender']
        #moderator = request.form['moderator']
        #system = request.form['system']
        #support = request.form['support']
        #access = request.form['access']
        #slots = request.form['slots']
        #language = request.form['language']

        if dienstdate == "None" or dienstdate == "" or suchender == "":
            flash(u'Bitte vernünftige Angaben machen! Versuchs nochmal :)','danger')
            ergebnis = dienstboerse.select().where(dienstboerse.c.aktiv==1).order_by(asc('dienstdate')).execute().fetchall() # Super wichtig! Das .fetchall() macht das Objekt erst zum list-like-item, das dann iterable ist! ergebnis = [(1, u'2017-10-29 21:00', u'domi', u'Crotas Ende', 250, u"Domi's Party", u'domi.leicht@gmail.com'), (2, u'2017-10-29 21:00', u'Test', u'Test', 400, u'Test', None)]
            return render_template("de_form.html", ergebnis=ergebnis)
        else:
            flash(u'Dein Angebot wurde erfolgreich eingetragen!','success')
            con = engine.connect()
            con.execute(dienstboerse.insert(), dienstdate=dienstdate, suchender=suchender, dienstart=dienstart, dienstgruppe=dienstgruppe, motivation=motivation, kommentar=kommentar)
            ergebnis = dienstboerse.select().where(dienstboerse.c.aktiv==1).execute().fetchall() # Super wichtig! Das .fetchall() macht das Objekt erst zum list-like-item, das dann iterable ist! ergebnis = [(1, u'2017-10-29 21:00', u'domi', u'Crotas Ende', 250, u"Domi's Party", u'domi.leicht@gmail.com'), (2, u'2017-10-29 21:00', u'Test', u'Test', 400, u'Test', None)]
            return redirect(url_for('de_form'))
    else:
        # FAILED
        flash(u'ReCaptcha nicht korrekt ausgefüllt. Dein Angebot wurde nicht eingetragen!','danger')
        ergebnis = dienstboerse.select().where(dienstboerse.c.aktiv==1).order_by(asc('dienstdate')).execute().fetchall() # Super wichtig! Das .fetchall() macht das Objekt erst zum list-like-item, das dann iterable ist! ergebnis = [(1, u'2017-10-29 21:00', u'domi', u'Crotas Ende', 250, u"Domi's Party", u'domi.leicht@gmail.com'), (2, u'2017-10-29 21:00', u'Test', u'Test', 400, u'Test', None)]
        return render_template("de_form.html", ergebnis=ergebnis)


@app.route('/faq')
def faq():
    return render_template("de_faq.html")

if __name__ == '__main__':
##########
# app.debug and app.reload should only be used locally!
#    app.debug=True
#    app.reload=True
    app.run()