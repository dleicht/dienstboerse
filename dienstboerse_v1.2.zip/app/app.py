# -*- coding: utf-8 -*-
from flask import Flask
from flask import request
from flask import render_template
from flask import redirect, url_for, flash, g
from sqlalchemy import create_engine, MetaData, Table, desc, asc, text, func, select, and_, or_
from sqlalchemy.sql import label
from flask_recaptcha import ReCaptcha
from random import randint
#from flask_babel import Babel, gettext

app = Flask(__name__)
app.config.from_object('config')
#app.config.from_pyfile('mysettings.cfg')
#babel = Babel(app)

##########
# DevMode:
devmode = False

##########
# ReCaptcha config:
recaptcha = ReCaptcha(app=app)

##########
# pythonanywhere.com MySQL engine:
engine = create_engine('mysql+mysqldb://kickass:SQL-kickass-05@kickass.mysql.pythonanywhere-services.com/kickass$default', convert_unicode=True, pool_recycle=280)

##########
# local Sqlite engine
#engine = create_engine('sqlite:////Users/domi/Entwicklung/raidfinder.de/app/raidfinder.db', convert_unicode=True)

metadata = MetaData(bind=engine)
dienstboerse = Table('dienstboerse', metadata, autoload=True)

##########
# Babel config:
# @babel.localeselector
# def get_locale():
#     current_locale = request.accept_languages.best_match(app.config['LANGUAGES'].keys())
#     print current_locale
#     g.current_locale = current_locale
#     return current_locale

##########
# views galore:
@app.route('/index', methods=["GET", "POST"])
@app.route('/', methods=["GET", "POST"])
def de_form():
    if devmode:
        return render_template("de_wartung.html")

    if request.method == "GET":
        ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
        #ergebnis = dienstboerse.select().where(dienstboerse.c.aktiv==1).order_by(asc('dienstdate')).execute().fetchall()
        return render_template("de_form.html", ergebnis=ergebnis)

    if 'button_mods' in request.form:
        moderator_id = request.form['button_mods']
        form_pin = str(request.form['form_pin']).strip()
        db_pin = str(select([dienstboerse.c.pin]).where(dienstboerse.c.id==moderator_id).execute().fetchall()[0][0])
        moderator_state = select([dienstboerse.c.moderator]).where(dienstboerse.c.id==moderator_id).execute().fetchall()[0][0]

        if form_pin == db_pin:
            if moderator_state == 0:
                con = engine.connect()
                con.execute(dienstboerse.update().where(dienstboerse.c.id==moderator_id).values(moderator=1))
                ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
                return render_template("de_form.html", ergebnis=ergebnis)
            else:
                con = engine.connect()
                con.execute(dienstboerse.update().where(dienstboerse.c.id==moderator_id).values(moderator=0))
                ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
                return render_template("de_form.html", ergebnis=ergebnis)
        else:
            flash(u'PIN '+form_pin+' ist nicht korrekt!','danger')
            ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
            return render_template("de_form.html", ergebnis=ergebnis)

    if 'button_delete' in request.form:
        moderator_id = request.form['button_delete']
        form_pin = str(request.form['form_pin']).strip()
        db_pin = str(select([dienstboerse.c.pin]).where(dienstboerse.c.id==moderator_id).execute().fetchall()[0][0])

        if form_pin == db_pin:
            con = engine.connect()
            con.execute(dienstboerse.update().where(dienstboerse.c.id==moderator_id).values(aktiv=0))
            ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
            return render_template("de_form.html", ergebnis=ergebnis)
        else:
            flash(u'PIN '+form_pin+' ist nicht korrekt!','danger')
            ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
            return render_template("de_form.html", ergebnis=ergebnis)

    if recaptcha.verify():
        # SUCCESS
        dienstdate = request.form['dienstdate']
        suchender = request.form['suchender']
        dienstart = request.form['dienstart']
        dienstgruppe = request.form['dienstgruppe']
        motivation = request.form['motivation']
        kommentar = request.form['kommentar']
        pin = randint(100000,999999)
        #annehmender = request.form['annehmender']
        #moderator = request.form['moderator']
        #system = request.form['system']
        #support = request.form['support']
        #access = request.form['access']
        #slots = request.form['slots']
        #language = request.form['language']

        if dienstdate == "None" or dienstdate == "" or suchender == "":
            flash(u'Bitte vernünftige Angaben machen! Versuchs nochmal :)','warning')
            ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
            return render_template("de_form.html", ergebnis=ergebnis)
        else:
            flash(u'Dein Angebot wurde erfolgreich eingetragen! Deine PIN lautet: '+str(pin),'success')
            con = engine.connect()
            con.execute(dienstboerse.insert(), dienstdate=dienstdate, suchender=suchender, dienstart=dienstart, dienstgruppe=dienstgruppe, motivation=motivation, kommentar=kommentar, pin=pin)
            ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
            return render_template("de_form.html", ergebnis=ergebnis)
    else:
        # FAILED
        flash(u'ReCaptcha nicht korrekt ausgefüllt. Dein Angebot wurde nicht eingetragen!','danger')
        ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
        return render_template("de_form.html", ergebnis=ergebnis)

@app.route('/devmode_1', methods=["GET", "POST"])
def dev_form():
    if request.method == "GET":
        ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
        #ergebnis = dienstboerse.select().where(dienstboerse.c.aktiv==1).order_by(asc('dienstdate')).execute().fetchall()
        return render_template("dev_form.html", ergebnis=ergebnis)

    if 'button_mods' in request.form:
        moderator_id = request.form['button_mods']
        con = engine.connect()
        con.execute(dienstboerse.update().where(dienstboerse.c.id==moderator_id).values(moderator=1))
        ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
        return render_template("dev_form.html", ergebnis=ergebnis)

    if recaptcha.verify():
        # SUCCESS
        dienstdate = request.form['dienstdate']
        suchender = request.form['suchender']
        dienstart = request.form['dienstart']
        dienstgruppe = request.form['dienstgruppe']
        motivation = request.form['motivation']
        kommentar = request.form['kommentar']
        pin = randint(100000,999999)
        #annehmender = request.form['annehmender']
        #moderator = request.form['moderator']
        #system = request.form['system']
        #support = request.form['support']
        #access = request.form['access']
        #slots = request.form['slots']
        #language = request.form['language']

        if dienstdate == "None" or dienstdate == "" or suchender == "":
            flash(u'Bitte vernünftige Angaben machen! Versuchs nochmal :)','danger')
            ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
            return render_template("dev_form.html", ergebnis=ergebnis)
        else:
            flash(u'Dein Angebot wurde erfolgreich eingetragen! Deine PIN lautet: '+str(pin),'success')
            con = engine.connect()
            con.execute(dienstboerse.insert(), dienstdate=dienstdate, suchender=suchender, dienstart=dienstart, dienstgruppe=dienstgruppe, motivation=motivation, kommentar=kommentar, pin=pin)
            ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
            return render_template("dev_form.html", ergebnis=ergebnis)
    else:
        # FAILED
        flash(u'ReCaptcha nicht korrekt ausgefüllt. Dein Angebot wurde nicht eingetragen!','danger')
        ergebnis = select([label('dienstdate', func.date_format(dienstboerse.c.dienstdate, '%d.%m.%Y %H:%i')), dienstboerse.c.id, dienstboerse.c.suchender, dienstboerse.c.motivation, dienstboerse.c.annehmender, dienstboerse.c.moderator, dienstboerse.c.dienstart, dienstboerse.c.dienstgruppe, dienstboerse.c.aktiv, dienstboerse.c.kommentar, dienstboerse.c.pin]).where(dienstboerse.c.aktiv==1).order_by(dienstboerse.c.dienstdate).execute().fetchall()
        return render_template("dev_form.html", ergebnis=ergebnis)

@app.route('/faq')
def faq():
    return render_template("de_faq.html")

if __name__ == '__main__':
##########
# app.debug and app.reload should only be used locally!
#    app.debug=True
#    app.reload=True
    app.run()